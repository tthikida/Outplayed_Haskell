module MyFunctions.InitializeGame where

import Data
import Control.Monad.State
import System.IO

initializeGame :: StateT Game IO ()
initializeGame = do
    liftIO $ do 
        hSetBuffering stdin NoBuffering
        hSetEcho stdin False
    modify (\b -> b { gGameStarted = True
                    , gP1Num     = 0
                    , gP2Num     = 0
                    , gTotal     = 0
                    , gP1Adv     = False
                    , gP2Adv     = False
                    , gWhosTurn  = Player1
                    , gP1Score   = 0
                    , gP2Score   = 0
                    })
    