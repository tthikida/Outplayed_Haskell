module MyFunctions.PlayersWrong where

import Control.Monad.State
import MyFunctions.DisplayGuesses
import Data
import System.Console.ANSI
import MyFunctions.SwitchTurns
import MyFunctions.MyPrintf
import MyFunctions.GetCurrentPlayer ( getCurrentPlayer )

playersWrong :: StateT Game IO ()
playersWrong = do
    p1Adv    <- gets gP1Adv
    p2Adv    <- gets gP2Adv
    whosTurn <- gets gWhosTurn
    p1Name   <- gets gP1Name
    p2Name   <- gets gP2Name
    
    if p1Adv || p2Adv
    then do
        modify (\p -> p {gWhosTurn = switchTurns whosTurn, gP1Adv = False, gP2Adv = False, gMessage = LostAdvantage})
    else do 
        modify (\p -> p {gWhosTurn = switchTurns whosTurn, gP1Adv = False, gP2Adv = False, gMessage = Wrong})