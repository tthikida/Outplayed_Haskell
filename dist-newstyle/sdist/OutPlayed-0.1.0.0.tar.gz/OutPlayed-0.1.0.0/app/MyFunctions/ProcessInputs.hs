module MyFunctions.ProcessInputs where

import MyFunctions.MyPrintf
import MyFunctions.PlayersWrong ( playersWrong )
import MyFunctions.P1ScorePoint
import MyFunctions.P2ScorePoint
import Data
import Control.Monad.State

processInputs :: StateT Game IO ()
processInputs = do
    whosTurn <- gets gWhosTurn
    p1Score  <- gets gP1Score
    p2Score  <- gets gP2Score
    p1Adv    <- gets gP1Adv
    p2Adv    <- gets gP2Adv
    p1Name   <- gets gP1Name
    p2Name   <- gets gP2Name
    total    <- gets gTotal
    pAns     <- gets gPAnswer

    -- player 1 guess correct
    if      total == pAns && whosTurn == Player1
    then do 
        if p1Adv
        then do
            p1ScorePoint
        else do
            modify (\b -> b {gP1Adv = True, gP2Adv = False, gMessage = Advantage})

    -- player 2 guess correct  
    else if total == pAns && whosTurn == Player2
    then do 
        if p2Adv
        then do
            p2ScorePoint
        else do
            modify (\b -> b {gP2Adv = True, gP1Adv = False, gMessage = Advantage})
    
    -- Players guessed wrong.  
    else do
        playersWrong 