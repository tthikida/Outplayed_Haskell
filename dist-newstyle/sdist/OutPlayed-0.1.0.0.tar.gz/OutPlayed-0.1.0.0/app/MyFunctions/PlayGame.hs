module MyFunctions.PlayGame where

import System.IO
import System.Console.ANSI
import Control.Monad.State
import Data
import Setup ( setup )
import MyFunctions.GetInputsAndTotal
import MyFunctions.Rendering
import MyFunctions.ProcessInputs


playGame :: StateT Game IO ()
playGame = do
    p1Name      <- gets gP1Name
    p2Name      <- gets gP2Name
    gameStarted <- gets gGameStarted
     
    if  not gameStarted
    then do 
        setup
        playGame
    else do
        whosTurn  <- gets gWhosTurn
        renderScene

        if whosTurn == Player1
        then do
            getInputsAndTotal_P1First
            processInputs
            playGame
        else do
            getInputsAndTotal_P2First
            processInputs
            playGame