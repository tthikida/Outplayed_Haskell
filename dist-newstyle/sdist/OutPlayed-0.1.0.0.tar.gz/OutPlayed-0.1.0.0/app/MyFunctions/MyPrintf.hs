module MyFunctions.MyPrintf where

import System.Console.ANSI

printColorName :: Color -> String -> IO ()
printColorName color name = do    
    setSGR [SetColor Foreground Vivid color]
    putStr name
    setSGR [Reset]

printColorString :: Color -> String -> IO ()
printColorString color str = do    
    setSGR [SetColor Foreground Vivid color]
    putStr str
    setSGR [Reset]

msgY :: Int
msgY = 26

msgX :: Int
msgX = 29

printInvalidButton :: IO ()
printInvalidButton = do    
    setCursorPosition msgY (msgX-2)
    setSGR [SetColor Foreground Vivid Red]
    putStrLn "Invalid button...try again."
    setSGR [Reset]

printPlayerAdv :: String -> IO ()
printPlayerAdv name = do    
    setCursorPosition msgY (msgX-2)
    setSGR [SetColor Foreground Vivid Green]
    putStrLn $ name ++ " gains the advantage."
    setSGR [Reset]

printLostAdvantage :: String -> IO ()
printLostAdvantage name = do
    setCursorPosition msgY msgX
    setSGR [SetColor Foreground Vivid Red]
    putStrLn $ name ++ " loses the advantage."
    setSGR [Reset]

printWrong :: IO ()
printWrong = do    
    setCursorPosition msgY msgX
    setSGR [SetColor Foreground Vivid Red]
    putStrLn "WRONG! Switch it up. \n"
    setSGR [Reset]

printPlayerPointScored :: String -> IO ()
printPlayerPointScored name = do
    setCursorPosition msgY msgX    
    setSGR [SetColor Foreground Vivid Green]
    putStrLn $ "Point scored for " ++ name ++ "!"
    setSGR [Reset]

printPlayerWins :: String -> IO ()
printPlayerWins name = do    
    setCursorPosition msgY msgX
    setSGR [SetColor Foreground Vivid Green]
    putStr $ name ++ " Wins!!!\n\n"
    setSGR [Reset]

printDefault :: IO ()
printDefault = do
    setCursorPosition msgY msgX
    putStr "Don't get outplayed!"

apX1 :: Int
apX1 = 8

apY1 :: Int
apY1 = 11

printAP1 :: IO ()
printAP1 = do
    setCursorPosition apY1 apX1
    putStrLn " █████  "
    setCursorPosition (apY1+1) apX1
    putStrLn "██   ██"
    setCursorPosition (apY1+2) apX1
    putStrLn "███████" 
    setCursorPosition (apY1+3) apX1
    putStrLn "██   ██"
    setCursorPosition (apY1+4) apX1
    putStrLn "██   ██"

apX2 :: Int
apX2 = 63

apY2 :: Int
apY2 = 11

printAP2 :: IO ()
printAP2 = do
    setCursorPosition apY2 apX2
    putStrLn " █████  "
    setCursorPosition (apY2+1) apX2
    putStrLn "██   ██"
    setCursorPosition (apY2+2) apX2
    putStrLn "███████" 
    setCursorPosition (apY2+3) apX2
    putStrLn "██   ██"
    setCursorPosition (apY2+4) apX2
    putStrLn "██   ██"  

printLogo :: IO ()
printLogo = do
    setCursorPosition 1 4
    putStr ".|''''|,            ||            '||`                             ||` "
    setCursorPosition 2 4
    putStr "||    ||            ||             ||                              ||  "
    setCursorPosition 3 4
    putStr "||    || '||  ||` ''||''  '||''|,  ||   '''|.  '||  ||` .|''|, .|''||  "
    setCursorPosition 4 4
    putStr "||    ||  ||  ||    ||     ||  ||  ||  .|''||   `|..||  ||..|| ||  ||  "
    setCursorPosition 5 4
    putStr "`|....|'  `|..'|.   `|..'  ||..|' .||. `|..||.      ||  `|...  `|..||. "
    setCursorPosition 6 4
    putStr "                           ||                    ,  |'       "
    setCursorPosition 7 4
    putStrLn "                          .||                     ''       "

printBG :: IO ()
printBG = do
    setCursorPosition 10 23
    setSGR [SetColor Background Vivid Yellow]
    putStrLn " "
    setSGR [Reset]