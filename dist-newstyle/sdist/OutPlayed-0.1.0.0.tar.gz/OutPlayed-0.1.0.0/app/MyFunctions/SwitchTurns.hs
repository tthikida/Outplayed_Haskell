module MyFunctions.SwitchTurns where

import Data

switchTurns :: Player -> Player
switchTurns p = if p == Player1 then Player2 else Player1