module MyFunctions.Scoreboard where

import Control.Monad.State
import Data
import System.Console.ANSI
import MyFunctions.MyPrintf
import MyFunctions.Numbers

scoreboard :: StateT Game IO ()
scoreboard = do 
    whosTurn <- gets gWhosTurn
    p1Score  <- gets gP1Score
    p2Score  <- gets gP2Score
    p1Adv    <- gets gP1Adv
    p2Adv    <- gets gP2Adv
    p1Name   <- gets gP1Name
    p2Name   <- gets gP2Name

    liftIO $ setCursorPosition 13 37
    liftIO $ putStrLn "Score "
    if whosTurn == Player1 && p1Adv
        then do 
            liftIO $ do
                setCursorPosition 9 27
                printColorName Magenta p1Name 
                case p1Score of
                    0 -> score0P1
                    1 -> score1P1
                    2 -> score2P1
                    3 -> score3P1
                    _ -> score0P1

                printAP1
    
                setCursorPosition 9 45
                printColorName Blue p2Name
                case p2Score of
                    0 -> score0P2
                    1 -> score1P2
                    2 -> score2P2
                    3 -> score3P2
                    _ -> score0P2

    else if whosTurn == Player2 && p2Adv
        then do 
            liftIO $ do
                setCursorPosition 9 27
                printColorName Magenta p1Name
                case p1Score of
                    0 -> score0P1
                    1 -> score1P1
                    2 -> score2P1
                    3 -> score3P1
                    _ -> score0P1

                printAP2

                setCursorPosition 9 45
                printColorName Blue p2Name
                case p2Score of
                    0 -> score0P2
                    1 -> score1P2
                    2 -> score2P2
                    3 -> score3P2
                    _ -> score0P2

                
    else do
        if whosTurn == Player1
            then do
                liftIO $ do 
                    setCursorPosition 9 27
                    printColorName Magenta p1Name
                    case p1Score of
                        0 -> score0P1
                        1 -> score1P1
                        2 -> score2P1
                        3 -> score3P1
                        _ -> score0P1

                    setCursorPosition 9 45
                    printColorName Blue p2Name
                    case p2Score of
                        0 -> score0P2
                        1 -> score1P2
                        2 -> score2P2
                        3 -> score3P2
                        _ -> score0P2
            else do
                liftIO $ do
                    setCursorPosition 9 27
                    printColorName Magenta p1Name
                    case p1Score of
                        0 -> score0P1
                        1 -> score1P1
                        2 -> score2P1
                        3 -> score3P1
                        _ -> score0P1

                    setCursorPosition 9 45
                    printColorName Blue p2Name
                    case p2Score of
                        0 -> score0P2
                        1 -> score1P2
                        2 -> score2P2
                        3 -> score3P2
                        _ -> score0P2