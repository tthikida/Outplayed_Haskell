module MyFunctions.P2ScorePoint where

import Control.Monad.State
import Data
import MyFunctions.DisplayGuesses
import System.Console.ANSI
import MyFunctions.Scoreboard ( scoreboard )
import MyFunctions.MyPrintf

p2ScorePoint :: StateT Game IO ()
p2ScorePoint = do
    p2Name   <- gets gP2Name
    p2Score  <- gets gP2Score

    modify (\b -> b {gP2Score = p2Score + 1, gP2Adv = False})
    newScore <- gets gP2Score

    if newScore == 3
    then do 
        -- displayGuesses
        -- scoreboard
        liftIO $ do 
            printPlayerWins p2Name
            putStrLn "Press Enter to start again"
        _ <- liftIO getChar
        modify (\w -> w {gGameStarted = False, gP2Adv = False})
    else do
        modify (\w -> w {gMessage = Point})