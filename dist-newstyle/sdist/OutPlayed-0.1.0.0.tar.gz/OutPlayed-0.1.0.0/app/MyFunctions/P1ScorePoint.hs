module MyFunctions.P1ScorePoint where

import Control.Monad.State
import Data
import MyFunctions.DisplayGuesses
import System.Console.ANSI
import MyFunctions.Scoreboard
import MyFunctions.MyPrintf
import MyFunctions.Rendering (renderScene)

p1ScorePoint :: StateT Game IO ()
p1ScorePoint = do
    p1Name   <- gets gP1Name
    p1Score  <- gets gP1Score

    modify (\b -> b {gP1Score = p1Score + 1, gP1Adv = False})
    newScore <- gets gP1Score

    if newScore == 3
    then do 
        modify (\w -> w {gMessage = Win})
        renderScene
        liftIO $ do 
            printPlayerWins p1Name 
            putStrLn "Press Enter to start again"
        _ <- liftIO getChar
        modify (\w -> w {gGameStarted = False, gP1Adv = False})
    else do
        modify (\w -> w {gMessage = Point})