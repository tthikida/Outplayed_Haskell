module Main where

import Data
import MyFunctions.PlayGame
import Control.Monad.State
import MyFunctions.GameOver



main :: IO ()
main = do
    game <- mkGame
    runStateT playGame game
    gameOver